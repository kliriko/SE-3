# Resource Center (DnD Assistant)

Monolithic 3-layer web application with authentication, content management, REST + GraphQL APIs, and React CSR frontend.

## Features

- Session-based auth with email verification flow.
- Roles: `user` (manage own characters), `dm` (manage all characters).
- CRUD for characters + activation/deactivation.
- Search and filtering by query, class, active status.
- REST and GraphQL API versions for the same business logic.
- SSE auto-refresh after character changes (AJAX-like live updates).
- Client + server data validation.
- Postman collection for backend API testing.

## Stack

- Backend: Node.js, Express, GraphQL, SQLite (`better-sqlite3`), `express-session`.
- Frontend: React + Vite, Bootstrap.

## Architecture

Backend follows separation of concerns:

- `controllers` - transport layer
- `services` - business logic
- `repositories` - data access
- `routes` / `graphql` - API endpoints
- `middlewares` - auth, validation, errors

## Quick Start

1. Install dependencies:

```bash
npm install
npm install --prefix server
npm install --prefix client
```

2. Configure environment:

```bash
cp server/.env.example server/.env
```

3. Run app:

```bash
npm run dev
```

- Frontend: http://localhost:5173
- Backend: http://localhost:4000
- GraphQL playground: http://localhost:4000/api/graphql

## Default Dungeon Master account

- Email: `dm@resource-center.local`
- Password: `dm12345`

You can change these in `server/.env` with `DM_EMAIL` and `DM_PASSWORD`.

## Email verification in development

Registration response contains `verifyLink` and `debugMailPayload`. Open `verifyLink` in browser to verify email.

## REST testing

Import `postman-resource-center.json` to Postman and use the provided requests.

## GraphQL sample

```graphql
query {
  characters {
    id
    name
    className
    level
    ownerName
    isActive
  }
}
```

## Requirements Coverage Checklist

Project title: Resource Center.

- 3-layer monolithic architecture (SoC): implemented (`routes/graphql -> controllers -> services -> repositories`).
- Backend + client-side rendering frontend: implemented (Express API + React/Vite CSR).
- User interface + administrator capabilities: implemented through role-based UI (`user`, `dm`) with different permissions.
- REST and GraphQL versions: implemented for core character workflows.
- CRUD + activation/deactivation: implemented in both REST and GraphQL.
- Client and server validation: implemented.
- Session support and access protection: implemented (`express-session`, auth middleware, role checks, helmet, rate limit).
- AJAX auto-refresh after content changes: implemented via SSE (`/api/events/characters`).
- Postman backend testing: REST collection included (`postman-resource-center.json`).
- Search and filtering: implemented (`q`, `className`, `isActive`).
- Email-based registration confirmation: implemented (verification token + verification endpoint + email sender service).

Notes for defense:

- In development mode, email transport uses Nodemailer JSON transport, so verification data is returned for easy local testing.
- Postman collection currently focuses on REST endpoints. GraphQL can be tested via GraphiQL or by adding `/api/graphql` requests in Postman.
